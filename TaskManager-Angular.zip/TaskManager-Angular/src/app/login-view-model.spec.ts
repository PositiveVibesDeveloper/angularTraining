import { LoginViewModel } from './login-view-model';

describe('LoginViewModel', () => {
  it('should create an instance', () => {
    expect(new LoginViewModel()).toBeTruthy();
  });
});
