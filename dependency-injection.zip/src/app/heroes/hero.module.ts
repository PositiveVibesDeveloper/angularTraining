import { NgModule } from '@angular/core';

@NgModule({})
export class HeroModule {
}
