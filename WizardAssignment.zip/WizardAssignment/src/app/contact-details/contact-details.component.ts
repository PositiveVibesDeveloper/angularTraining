import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.scss']
})
export class ContactDetailsComponent implements OnInit {

  public state: any;
  public firstName : string;
  public lastName :string;
  constructor(private router:Router,private activatedRoute:ActivatedRoute) {
    this.firstName = this.activatedRoute.snapshot.queryParams['firstName'];
    this.lastName = this.activatedRoute.snapshot.queryParams['lastName'];

  }

  ngOnInit() {


  }

  goBack(){
    console.log('Click back')
    this.router.navigate(['/step-1'],{queryParams:{firstName:this.firstName,lastName:this.lastName},state:{firstName:this.firstName,lastName:this.lastName}});
  }

}
