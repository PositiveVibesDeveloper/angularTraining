import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { logging } from 'protractor';

@Component({
  selector: 'app-personal-details',
  templateUrl: './personal-details.component.html',
  styleUrls: ['./personal-details.component.scss']
})
export class PersonalDetailsComponent implements OnInit {
  firstName : string;
  lastName : string;
  constructor(private route: Router,private activatedRoute:ActivatedRoute ) {
    this.firstName = this.activatedRoute.snapshot.queryParams['firstName'];
    this.lastName = this.activatedRoute.snapshot.queryParams['lastName'];

   console.log('Values from state-->'+ JSON.stringify(this.route.getCurrentNavigation().extras.state))
   // console.log('--->'+this.firstName)
   }

  ngOnInit() {
  }
  clickSubmit(){

    console.log(this.firstName)
    this.route.navigate(['/step-2'] , { queryParams: { firstName : this.firstName,lastName:this.lastName }});

  }
}
