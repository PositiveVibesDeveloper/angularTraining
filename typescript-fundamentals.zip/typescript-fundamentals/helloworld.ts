let message: tring = 'Hello World';
console.log(message);