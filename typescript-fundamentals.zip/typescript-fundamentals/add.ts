let a = 20;
let b = 30;
let c = a + b;
console.log( c );