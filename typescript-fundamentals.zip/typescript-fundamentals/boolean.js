var isDone = false;
var isProgress = true;
console.log('isDone-->' + isDone + '--' + 'isProgress-->' + isProgress);
