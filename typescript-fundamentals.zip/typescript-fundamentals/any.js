function ProcessData(x, y) {
    console.log(x, y);
    console.log(x + y);
    return x + y;
}
var result;
result = ProcessData("Hello ", "Any!"); //Hello Any!  
result = ProcessData(2, 3); //5  
result = ProcessData(true, false); //5  
