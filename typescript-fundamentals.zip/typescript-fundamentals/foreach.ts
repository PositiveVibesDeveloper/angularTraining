let apps = ['WhatsApp', 'Instagram', 'Facebook'];  
let playStore = [];  
  
apps.forEach(function(item){  
  playStore.push(item)  
});  
  
console.log(playStore);  