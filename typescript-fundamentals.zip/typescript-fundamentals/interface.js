var empObject = {};
empObject.name = "Abhishek";
empObject.age = 25;
empObject.gender = "Male";
empObject.empCode = 43;
console.log("Name: " + empObject.name);
console.log("Age: " + empObject.age);
console.log("Employee Code: " + empObject.empCode);
