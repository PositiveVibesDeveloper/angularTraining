enum Color {
    Red, Green, Blue
};

console.log(Color.Blue)