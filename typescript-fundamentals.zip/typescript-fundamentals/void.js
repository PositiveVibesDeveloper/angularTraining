function helloUser() {
    console.log("This is a welcome message");
}
console.log(helloUser());
