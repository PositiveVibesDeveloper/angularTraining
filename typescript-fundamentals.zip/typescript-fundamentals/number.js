var first = 12.0; // number   
var second = 0x37CF; // hexadecimal  
var third = 255; // octal  
var fourth = 57; // binary   
console.log(first); // 123  
console.log(second); // 14287  
console.log(third); // 255  
console.log(fourth); // 57  
