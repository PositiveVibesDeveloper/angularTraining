//Variable declared and assigned to null  
var a = null;   
console.log( a );   //output: null  
console.log( typeof(a) );   //output: object 