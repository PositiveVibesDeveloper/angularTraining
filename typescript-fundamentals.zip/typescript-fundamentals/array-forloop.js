var arr = new Array("Angular", "2200", "Java", "Abhishek");
var newarr = [];
arr.forEach(function (name) {
    console.log(name);
    newarr.push(name);
});
console.log(newarr);
