var ah;
ah = ["hi", 8];
console.log(ah);
