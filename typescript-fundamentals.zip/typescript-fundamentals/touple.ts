let ah:[string,number];
ah = ["hi",8];
console.log(ah)