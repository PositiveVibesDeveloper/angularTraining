var greeter = "hey hi";  
var times = 5;  
if (times > 3) {  
   var greeter = "Say Hello ";   
}  
console.log(greeter) //Output: Say Hello  