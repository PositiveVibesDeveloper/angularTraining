let n1 = 10, n2 = 22, n3 = 25    
if (n1 >= n2) {    
    if (n1 >= n3) {    
        console.log("The largest number is: " +n1)    
    }    
    else {    
        console.log("The largest number is: " +n3)    
    }    
}    
else {    
    if (n2 >= n3) {    
        console.log("The largest number is: " +n2)    
    }    
    else {    
        console.log("The largest number is: " +n3)    
    }    
} 