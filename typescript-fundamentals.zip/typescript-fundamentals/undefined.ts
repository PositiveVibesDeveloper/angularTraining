//Variable declaration without assigning any value to it  
var a;        
console.log(a);  //undefined  
console.log(typeof(a));  //undefined  
//console.log(undeclaredVar);  //Uncaught ReferenceError: undeclaredVar is not defined  