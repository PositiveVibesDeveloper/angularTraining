class Student {  
    public studCode: number;  
    studName: string;  
}  
  
let stud = new Student();  
stud.studCode = 101;  
stud.studName = "Joe Root";  
  
console.log(stud.studCode+ " "+stud.studName);  