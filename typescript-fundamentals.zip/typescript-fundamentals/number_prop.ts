console.log("Number Properties: ");   

console.log("A number variable can hold maximum value: " + Number.MAX_VALUE);   
console.log("A number variable can hold minimum value: " + Number.MIN_VALUE);   
console.log("Value of Negative Infinity: " + Number.NEGATIVE_INFINITY);   
console.log("Value of Positive Infinity:" + Number.POSITIVE_INFINITY);  
console.log("Example of NaN: " +Math.sqrt(-5)); // NaN  