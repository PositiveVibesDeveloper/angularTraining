var a = 20;
var b = 30;
var c = a + b;
console.log(c);
