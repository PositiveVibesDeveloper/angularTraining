let isDone :boolean = false;
let isProgress : boolean = true;
console.log('isDone-->'+isDone+'--'+'isProgress-->'+isProgress)