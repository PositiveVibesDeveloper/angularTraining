function constTest() {
    var VAR = 10;
    console.log("Value is: " + VAR);
}
constTest();
