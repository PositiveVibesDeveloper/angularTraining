let employeeName: string = "Rohan";   
let employeeDept: string = 'IT';   
  
// Before-ES6  
let output1: string = employeeName + " works in the " + employeeDept + " department.";   
  
// After-ES6  
let output2: string = `${employeeName} works in the ${employeeDept} department.`;   
  
console.log(output1);//Rohan works in the IT department.   
console.log(output2);//Rohan works in the IT department.  