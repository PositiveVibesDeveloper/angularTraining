let greeter = "hey hi";  
let times = 5;  
if (times > 3) {  
   let hello = "Say Hello Angular";   
   console.log(hello) // Output: Say Hello Angular  
}  
console.log(hello) // Compile error: greeter is not defined 