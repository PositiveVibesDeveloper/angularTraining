function greeter(person) {
    return "Hello, " + person;
}
var user = 'Angukar training';
console.log(greeter(user));
