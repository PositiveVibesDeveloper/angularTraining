function ProcessData(x: any, y: any) { 
                      console.log(x , y); 
                       console.log(x + y); 
                       return x + y;  
            }  
            let result: any;  
            result = ProcessData("Hello ", "Any!"); //Hello Any!  
            result = ProcessData(2, 3); //5  
            result = ProcessData(true, false); //5  