var employeeName = "Rohan";
var employeeDept = 'IT';
// Before-ES6  
var output1 = employeeName + " works in the " + employeeDept + " department.";
// After-ES6  
var output2 = "".concat(employeeName, " works in the ").concat(employeeDept, " department.");
console.log(output1); //Rohan works in the IT department.   
console.log(output2); //Rohan works in the IT department.  
