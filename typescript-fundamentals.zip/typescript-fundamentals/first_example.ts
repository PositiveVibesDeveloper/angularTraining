function greeter(person) {  
    return "Hello, " + person;  
}  
let user = 'Angukar training';  
console.log(greeter(user));  

